Run the program to generate original.bmp, output.ppm, and output.bmp.
Generated output files are not included yet because no program run outputs were supplied.
