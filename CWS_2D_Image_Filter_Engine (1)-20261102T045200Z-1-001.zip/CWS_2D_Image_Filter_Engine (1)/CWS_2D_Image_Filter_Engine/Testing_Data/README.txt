sample_input.ppm is the P3 PPM test image supplied with the project.
The program expects input.ppm in the same folder as main.cpp when it is run.
