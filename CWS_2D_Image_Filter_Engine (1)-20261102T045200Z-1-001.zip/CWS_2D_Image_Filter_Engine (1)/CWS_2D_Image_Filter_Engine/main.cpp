
#include <iostream>
#include <fstream>
#include <string>
#include <cmath>
#include <algorithm>
#include <cstdint>
#include <new>
using namespace std;

struct Image {
    int width=0,height=0;
    unsigned char *pixels=nullptr;
};


bool readNumber(ifstream &file,int &num) {
    file>>ws;

    while(file.peek()=='#') {
        string comment;
        getline(file,comment);
        file>>ws;
    }

    if(file>>num)
        return true;
    else
        return false;
}


bool loadImage(Image &img,string filename) {
    ifstream file(filename);

    if(!file) {
        cout<<"Could not open image\n";
        return false;
    }

    string format;
    file>>format;

    if(format!="P3") {
        cout<<"Only P3 PPM images are supported\n";
        return false;
    }

    int maxValue;

    if(!readNumber(file,img.width) ||
       !readNumber(file,img.height) ||
       !readNumber(file,maxValue)) {
        cout<<"Invalid image header\n";
        return false;
    }

    if(img.width<=0 || img.height<=0 || maxValue!=255 ||
       img.width>10000 || img.height>10000 ||
       (long long)img.width*img.height>20000000) {
        cout<<"Invalid image size\n";
        return false;
    }

    int size=img.width*img.height*3;

    img.pixels=new(nothrow) unsigned char[size];

    if(img.pixels==nullptr) {
        cout<<"Memory allocation failed\n";
        return false;
    }

    for(int i=0;i<size;i++) {
        int value;

        if(!readNumber(file,value) || value<0 || value>255) {
            cout<<"Invalid pixel data\n";
            delete[] img.pixels;
            img.pixels=nullptr;
            return false;
        }

        img.pixels[i]=value;
    }

    cout<<"Image loaded successfully\n";
    return true;
}

void copyPixels(Image &source,Image &target) {
    int size=source.width*source.height*3;

    for(int i=0;i<size;i++) {
        target.pixels[i]=source.pixels[i];
    }
}

bool saveImage(Image &img,string filename) {
    ofstream file(filename);

    if(!file) {
        cout<<"Could not save image\n";
        return false;
    }

    file<<"P3\n";
    file<<img.width<<" "<<img.height<<"\n255\n";

    for(int i=0;i<img.width*img.height*3;i+=3) {
        file<<(int)img.pixels[i]<<" ";
        file<<(int)img.pixels[i+1]<<" ";
        file<<(int)img.pixels[i+2]<<"\n";
    }

    return true;
}

void write16(ofstream &file,uint16_t value) {
    file.put(value&255);
    file.put((value>>8)&255);
}

void write32(ofstream &file,uint32_t value) {
    file.put(value&255);
    file.put((value>>8)&255);
    file.put((value>>16)&255);
    file.put((value>>24)&255);
}

bool saveBMP(Image &img,string filename) {
    ofstream file(filename,ios::binary);

    if(!file || img.pixels==nullptr)
        return false;

    int rowSize=(img.width*3+3)/4*4;
    int imageSize=rowSize*img.height;
    int fileSize=54+imageSize;

    file.put('B');
    file.put('M');

    write32(file,fileSize);
    write16(file,0);
    write16(file,0);
    write32(file,54);

    write32(file,40);
    write32(file,img.width);
    write32(file,img.height);
    write16(file,1);
    write16(file,24);
    write32(file,0);
    write32(file,imageSize);
    write32(file,2835);
    write32(file,2835);
    write32(file,0);
    write32(file,0);

    for(int y=img.height-1;y>=0;y--) {
        for(int x=0;x<img.width;x++) {
            int i=(y*img.width+x)*3;

            file.put(img.pixels[i+2]);
            file.put(img.pixels[i+1]);
            file.put(img.pixels[i]);
        }

        for(int p=img.width*3;p<rowSize;p++) {
            file.put(0);
        }
    }

    return file.good();
}

int clamp(int value) {
    return max(0,min(255,value));
}

bool grayscale(Image &img) {
    int size=img.width*img.height;

    for(int i=0;i<size;i++) {
        int pos=i*3;

        int gray=(img.pixels[pos]+img.pixels[pos+1]+
                  img.pixels[pos+2])/3;

        img.pixels[pos]=gray;
        img.pixels[pos+1]=gray;
        img.pixels[pos+2]=gray;
    }

    return true;
}

bool brightness(Image &img,int amount) {
    int size=img.width*img.height*3;

    for(int i=0;i<size;i++) {
        img.pixels[i]=clamp(img.pixels[i]+amount);
    }

    return true;
}

bool blur(Image &img) {
    int size=img.width*img.height*3;

    unsigned char *result=new(nothrow) unsigned char[size];

    if(result==nullptr)
        return false;

    for(int i=0;i<size;i++)
        result[i]=img.pixels[i];

    for(int y=1;y<img.height-1;y++) {
        for(int x=1;x<img.width-1;x++) {
            for(int c=0;c<3;c++) {
                int sum=0;

                for(int dy=-1;dy<=1;dy++) {
                    for(int dx=-1;dx<=1;dx++) {
                        int pos=((y+dy)*img.width+x+dx)*3+c;
                        sum+=img.pixels[pos];
                    }
                }

                int pos=(y*img.width+x)*3+c;
                result[pos]=sum/9;
            }
        }
    }

    for(int i=0;i<size;i++)
        img.pixels[i]=result[i];

    delete[] result;
    return true;
}

bool sharpen(Image &img) {
    int size=img.width*img.height*3;

    unsigned char *result=new(nothrow) unsigned char[size];

    if(result==nullptr)
        return false;

    for(int i=0;i<size;i++)
        result[i]=img.pixels[i];

    for(int y=1;y<img.height-1;y++) {
        for(int x=1;x<img.width-1;x++) {
            for(int c=0;c<3;c++) {
                int center=(y*img.width+x)*3+c;
                int up=((y-1)*img.width+x)*3+c;
                int down=((y+1)*img.width+x)*3+c;
                int left=(y*img.width+x-1)*3+c;
                int right=(y*img.width+x+1)*3+c;

                int value=5*img.pixels[center]-img.pixels[up]
                         -img.pixels[down]-img.pixels[left]
                         -img.pixels[right];

                result[center]=clamp(value);
            }
        }
    }

    for(int i=0;i<size;i++)
        img.pixels[i]=result[i];

    delete[] result;
    return true;
}

bool edgeDetection(Image &img) {
    int size=img.width*img.height*3;

    unsigned char *gray=new(nothrow) unsigned char[img.width*img.height];
    unsigned char *result=new(nothrow) unsigned char[size];

    if(gray==nullptr || result==nullptr) {
        delete[] gray;
        delete[] result;
        return false;
    }

    for(int i=0;i<size;i++)
        result[i]=img.pixels[i];

    for(int i=0;i<img.width*img.height;i++) {
        int pos=i*3;
        gray[i]=(img.pixels[pos]+img.pixels[pos+1]+
                 img.pixels[pos+2])/3;
    }

    int gx[3][3]={
        {-1,0,1},
        {-2,0,2},
        {-1,0,1}
    };

    int gy[3][3]={
        {-1,-2,-1},
        {0,0,0},
        {1,2,1}
    };

    for(int y=1;y<img.height-1;y++) {
        for(int x=1;x<img.width-1;x++) {
            int sumX=0,sumY=0;

            for(int dy=-1;dy<=1;dy++) {
                for(int dx=-1;dx<=1;dx++) {
                    int pixel=gray[(y+dy)*img.width+x+dx];

                    sumX+=pixel*gx[dy+1][dx+1];
                    sumY+=pixel*gy[dy+1][dx+1];
                }
            }

            int edge=clamp((int)sqrt(sumX*sumX+sumY*sumY));

            int pos=(y*img.width+x)*3;

            result[pos]=edge;
            result[pos+1]=edge;
            result[pos+2]=edge;
        }
    }

    for(int i=0;i<size;i++)
        img.pixels[i]=result[i];

    delete[] gray;
    delete[] result;

    return true;
}

int main() {
    Image img,original;

    if(!loadImage(img,"input.ppm")) {
        return 1;
    }

    original.width=img.width;
    original.height=img.height;

    original.pixels=new(nothrow) unsigned char[img.width*img.height*3];

    if(original.pixels==nullptr) {
        cout<<"Memory allocation failed\n";
        delete[] img.pixels;
        return 1;
    }

    copyPixels(img,original);

    if(saveBMP(original,"original.bmp"))
        cout<<"Original image saved\n";
    else
        cout<<"Could not save original image\n";

    int choice=-1;
    bool valid=true;

    cout<<"\n--- 2D Image Filter Engine ---\n";
    cout<<"1. Grayscale\n";
    cout<<"2. Increase brightness\n";
    cout<<"3. Decrease brightness\n";
    cout<<"4. Blur\n";
    cout<<"5. Sharpen\n";
    cout<<"6. Edge detection\n";
    cout<<"7. Save image\n";
    cout<<"8. Restore original image\n";
    cout<<"0. Exit\n";

    cout<<"Enter your choice: ";

    if(!(cin>>choice)) {
        cout<<"Invalid input\n";
        valid=false;
    }

    else if(choice==1) {
        copyPixels(original,img);
        valid=grayscale(img);
        cout<<"Grayscale applied\n";
    }

    else if(choice==2 || choice==3) {
        int amount;

        cout<<"Enter brightness amount (0-255): ";

        if(cin>>amount && amount>=0 && amount<=255) {
            copyPixels(original,img);

            if(choice==2) {
                valid=brightness(img,amount);
                cout<<"Brightness increased\n";
            }
            else {
                valid=brightness(img,-amount);
                cout<<"Brightness decreased\n";
            }
        }
        else {
            cout<<"Invalid brightness value\n";
            valid=false;
        }
    }

    else if(choice==4) {
        copyPixels(original,img);
        valid=blur(img);
        cout<<"Blur applied\n";
    }

    else if(choice==5) {
        copyPixels(original,img);
        valid=sharpen(img);
        cout<<"Sharpen applied\n";
    }

    else if(choice==6) {
        copyPixels(original,img);
        valid=edgeDetection(img);
        cout<<"Edge detection applied\n";
    }

    else if(choice==7) {
        cout<<"Saving current image\n";
    }

    else if(choice==8) {
        copyPixels(original,img);
        cout<<"Original image restored\n";
    }

    else if(choice==0) {
        cout<<"Program closed\n";
        valid=false;
    }

    else {
        cout<<"Invalid choice\n";
        valid=false;
    }

    if(valid && choice>=1 && choice<=8) {
        if(saveImage(img,"output.ppm"))
            cout<<"Output PPM saved\n";

        if(saveBMP(img,"output.bmp"))
            cout<<"Output BMP saved\n";
        else
            cout<<"Could not save output BMP\n";
    }

    delete[] img.pixels;
    delete[] original.pixels;

    return 0;
}
