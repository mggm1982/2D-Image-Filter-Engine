2D IMAGE FILTER ENGINE — C++
================================

Files:
- main.cpp: C++ source code.
- input.ppm: input image loaded by the program.
- Training_Data/: optional development/sample images (no ML training is used).
- Testing_Data/: supplied sample test image.
- Sample_Outputs/: place generated output files here.

REQUIREMENTS
- A C++ compiler with C++11 (or later) support.
- No external libraries are required; the program uses standard C++ headers.

HOW TO COMPILE
  g++ main.cpp -o filter

HOW TO RUN
  Windows: filter.exe
  Linux/macOS: ./filter

Keep input.ppm in the same working directory as the executable when running.
The program supports P3 PPM images with maximum channel value 255.
It generates original.bmp, output.ppm, and output.bmp in the working directory.

MENU OPTIONS
1 Grayscale | 2 Increase brightness | 3 Decrease brightness
4 Blur | 5 Sharpen | 6 Edge detection | 7 Save image
8 Restore original image | 0 Exit

NOTE
The program processes one selected menu option per run. Run it again to try another filter.
